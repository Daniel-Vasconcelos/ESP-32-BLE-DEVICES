#include "BLEHIDUnified.h"
#include "hid_descriptor_unified.h"
#include <BLEDevice.h>

BLEHIDUnified::BLEHIDUnified(const char* name) {
    deviceName = name;
}

void BLEHIDUnified::begin() {
    BLEDevice::init(deviceName);
    BLEServer* server = BLEDevice::createServer();
    hid = new BLEHIDDevice(server);

    inputReportKeyboard = hid->inputReport(1);
    inputReportMouse = hid->inputReport(2);
    inputReportTouch = hid->inputReport(3);
    inputReportGamepad = hid->inputReport(4);

    hid->manufacturer()->setValue("ESP32 Unified HID");
    hid->reportMap((uint8_t*)HIDReportDescriptor, sizeof(HIDReportDescriptor));
    hid->startServices();

    server->getAdvertising()->setAppearance(0x03C0); // Generic HID
    server->getAdvertising()->start();
}


void BLEHIDUnified::pressKey(uint8_t keycode) {
    uint8_t report[8] = {0};
    report[2] = keycode;
    inputReportKeyboard->setValue(report, sizeof(report));
    inputReportKeyboard->notify();
}

void BLEHIDUnified::releaseKey() {
    uint8_t report[8] = {0};
    inputReportKeyboard->setValue(report, sizeof(report));
    inputReportKeyboard->notify();
}

void BLEHIDUnified::moveMouse(int8_t dx, int8_t dy, int8_t wheel) {
    uint8_t report[4] = {0, (uint8_t)dx, (uint8_t)dy, (uint8_t)wheel};
    inputReportMouse->setValue(report, sizeof(report));
    inputReportMouse->notify();
}

void BLEHIDUnified::clickMouse(uint8_t buttons) {
    uint8_t report[4] = {buttons, 0, 0, 0};
    inputReportMouse->setValue(report, sizeof(report));
    inputReportMouse->notify();
}

void BLEHIDUnified::releaseMouse() {
    clickMouse(0);
}

void BLEHIDUnified::moveTouchTo(uint16_t x, uint16_t y) {
    touchDown(x, y);
}

void BLEHIDUnified::touchDown(uint16_t x, uint16_t y) {
    uint8_t report[5] = {0x01, (uint8_t)(x & 0xFF), (uint8_t)(x >> 8), (uint8_t)(y & 0xFF), (uint8_t)(y >> 8)};
    inputReportTouch->setValue(report, sizeof(report));
    inputReportTouch->notify();
}

void BLEHIDUnified::touchUp() {
    uint8_t report[5] = {0x00, 0, 0, 0, 0};
    inputReportTouch->setValue(report, sizeof(report));
    inputReportTouch->notify();
}

void BLEHIDUnified::updateGamepad(uint16_t buttons, int8_t lx, int8_t ly, int8_t rx, int8_t ry) {
    uint8_t report[6] = {
        (uint8_t)(buttons & 0xFF), (uint8_t)(buttons >> 8),
        (uint8_t)lx, (uint8_t)ly,
        (uint8_t)rx, (uint8_t)ry
    };
    inputReportGamepad->setValue(report, sizeof(report));
    inputReportGamepad->notify();
}
