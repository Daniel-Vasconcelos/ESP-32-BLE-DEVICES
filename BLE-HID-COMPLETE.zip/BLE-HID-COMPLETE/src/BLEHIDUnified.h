#ifndef BLE_HID_UNIFIED_H
#define BLE_HID_UNIFIED_H

#include <BLEHIDDevice.h>
#include <BLEServer.h>

class BLEHIDUnified {
public:
    BLEHIDUnified(const char* deviceName = "ESP32 HID Device");
    void begin();

    // Teclado
    void pressKey(uint8_t keycode);
    void releaseKey();

    // Mouse
    void moveMouse(int8_t dx, int8_t dy, int8_t wheel = 0);
    void clickMouse(uint8_t buttons);
    void releaseMouse();

    // Touchpad absoluto
    void moveTouchTo(uint16_t x, uint16_t y);
    void touchDown(uint16_t x, uint16_t y);
    void touchUp();

    // Gamepad
    void updateGamepad(uint16_t buttons, int8_t lx, int8_t ly, int8_t rx, int8_t ry);

private:
    BLEHIDDevice* hid;
    BLECharacteristic* inputReportKeyboard;
    BLECharacteristic* inputReportMouse;
    BLECharacteristic* inputReportTouch;
    BLECharacteristic* inputReportGamepad;
    const char* deviceName;
};

#endif
